print('Assalom alaykum')
print(4+ 4*2)
print(190/10)
print(2**10)
